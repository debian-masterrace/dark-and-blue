# Available Colorschemes

### powerline (default)

![lightline.vim - powerline](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/powerline.png)

### powerlineish

![lightline.vim - powerlineish](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/powerlineish.png)

### wombat

![lightline.vim - wombat](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/wombat.png)

### OldHope

![lightline.vim - OldHope](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/OldHope.png)

### PaperColor dark

![lightline.vim - PaperColor dark](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/PaperColor_dark.png)

### PaperColor light

![lightline.vim - PaperColor light](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/PaperColor_light.png)

### Tomorrow

![lightline.vim - Tomorrow](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/Tomorrow.png)

### Tomorrow Night

![lightline.vim - Tomorrow Night](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/Tomorrow_Night.png)

### Tomorrow Night Blue

![lightline.vim - Tomorrow Night Blue](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/Tomorrow_Night_Blue.png)

### Tomorrow Night Bright

![lightline.vim - Tomorrow Night Bright](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/Tomorrow_Night_Bright.png)

### Tomorrow Night Eighties

![lightline.vim - Tomorrow Night Eighties](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/Tomorrow_Night_Eighties.png)

### ayu_mirage

![lightline.vim - ayu mirage](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/ayu_mirage.png)

### ayu_light

![lightline.vim - ayu light](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/ayu_light.png)

### ayu_dark

![lightline.vim - ayu dark](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/ayu_dark.png)

### darcula

![lightline.vim - darcula](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/darcula.png)

### deus

![lightline.vim - deus](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/deus.png)

### jellybeans

![lightline.vim - jellybeans](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/jellybeans.png)

### selenized dark

![lightline.vim - selenized dark](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/selenized_dark.png)

### selenized black

![lightline.vim - selenized black](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/selenized_black.png)

### selenized light

![lightline.vim - selenized light](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/selenized_light.png)

### selenized white

![lightline.vim - selenized white](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/selenized_white.png)

### solarized dark

![lightline.vim - solarized dark](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/solarized_dark.png)

### solarized light

![lightline.vim - solarized light](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/solarized_light.png)

### materia

![lightline.vim - materia](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/materia.png)

### material

![lightline.vim - material](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/material.png)

### molokai

![lightline.vim - molokai](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/molokai.png)

### nord

![lightline.vim - nord](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/nord.png)

### seoul256

![lightline.vim - seoul256](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/seoul256.png)

### one dark

![lightline.vim - one dark](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/one_dark.png)

### one light

![lightline.vim - one light](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/one_light.png)

### srcery_drk

![lightline.vim - srcery_drk](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/srcery_drk.png)

### simpleblack

![lightline.vim - simpleblack](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/simpleblack.png)

### landscape

![lightline.vim - landscape](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/landscape.png)

### 16color dark

![lightline.vim - 16color dark](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/16color_dark.png)

### 16color light

![lightline.vim - 16color light](https://raw.githubusercontent.com/wiki/itchyny/lightline.vim/image/16color_light.png)
